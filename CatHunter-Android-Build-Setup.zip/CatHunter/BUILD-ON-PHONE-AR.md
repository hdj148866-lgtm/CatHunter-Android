# بناء APK من الهاتف عبر GitHub Actions

## مهم قبل البدء
هذا المشروع يحتاج رخصة Unity صالحة في GitHub Secret باسم `UNITY_LICENSE`. لا تضع ملف الرخصة أو كلمات المرور داخل ملفات المشروع العامة.

1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد (يجب أن يكون `Assets` و`Packages` و`ProjectSettings` في جذر المستودع، وليس داخل مجلد فرعي آخر).
2. في GitHub افتح Settings → Secrets and variables → Actions → New repository secret.
3. الاسم: `UNITY_LICENSE`، والقيمة هي نص رخصة Unity Personal المصدّر وفق تعليمات GameCI الرسمية.
4. افتح Actions → Build CatHunter Android APK → Run workflow.
5. عند نجاح البناء، افتح تشغيل workflow ونزّل Artifact باسم `CatHunter-Android-APK`، ثم فك ZIP وثبّت APK على هاتفك.

إذا لم تضف الرخصة أو كانت غير صالحة، فسيفشل البناء. لم يتم بناء APK أو اختبار اللعبة في هذه الحزمة.
