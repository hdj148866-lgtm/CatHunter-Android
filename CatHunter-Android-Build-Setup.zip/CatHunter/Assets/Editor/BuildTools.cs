#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
namespace CatHunter.EditorTools {
public static class BuildTools {
  const string ScenePath="Assets/Scenes/Main.unity";
  [MenuItem("CatHunter/1) إعداد المشروع (مشهد + إعدادات Android)")]
  public static void Setup(){
    Directory.CreateDirectory("Assets/Scenes");
    var sc=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single); EditorSceneManager.SaveScene(sc,ScenePath);
    EditorBuildSettings.scenes=new[]{ new EditorBuildSettingsScene(ScenePath,true) };
    PlayerSettings.companyName="CatHunterStudio"; PlayerSettings.productName="Cat Hunter Starry Night";
    PlayerSettings.SetApplicationIdentifier(UnityEditor.Build.NamedBuildTarget.Android,"com.cathunterstudio.starrynight");
    PlayerSettings.defaultInterfaceOrientation=UIOrientation.AutoRotation;
    PlayerSettings.allowedAutorotateToPortrait=false; PlayerSettings.allowedAutorotateToPortraitUpsideDown=false; PlayerSettings.allowedAutorotateToLandscapeLeft=true; PlayerSettings.allowedAutorotateToLandscapeRight=true;
    PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel24;
    PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);
    PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
    // الشيدرات المستخدمة وقت التشغيل يجب ألا تُحذف من البناء
    var gs=new SerializedObject(AssetDatabase.LoadAssetAtPath<Object>("ProjectSettings/GraphicsSettings.asset")); var arr=gs.FindProperty("m_AlwaysIncludedShaders");
    foreach(var n in new[]{ "Standard","Sprites/Default","Skybox/Procedural","Unlit/Color","Universal Render Pipeline/Lit","Universal Render Pipeline/Unlit" }){
      var sh=Shader.Find(n); if(sh==null) continue; bool has=false; for(int i=0;i<arr.arraySize;i++) if(arr.GetArrayElementAtIndex(i).objectReferenceValue==sh) has=true;
      if(!has){ arr.arraySize++; arr.GetArrayElementAtIndex(arr.arraySize-1).objectReferenceValue=sh; } }
    gs.ApplyModifiedProperties();
    // اللمس عبر نظام الإدخال القديم (أو Both)
    var ps=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset")[0]); var ih=ps.FindProperty("activeInputHandler"); if(ih!=null){ ih.intValue=2; ps.ApplyModifiedProperties(); }
    AssetDatabase.SaveAssets(); Debug.Log("CatHunter: تم الإعداد. أعد تشغيل Unity إن غُيّر نظام الإدخال."); }
  [MenuItem("CatHunter/2) بناء APK")] public static void BuildApk(){ Build(false); }
  [MenuItem("CatHunter/3) بناء AAB (لمتجر Google Play)")] public static void BuildAab(){ Build(true); }
  public static void BuildApkCli(){ Setup(); Build(false); }
  static void Build(bool aab){
    if(!File.Exists(ScenePath)) Setup();
    Directory.CreateDirectory("Builds"); EditorUserBuildSettings.buildAppBundle=aab;
    var o=new BuildPlayerOptions{ scenes=new[]{ ScenePath }, locationPathName=aab?"Builds/CatHunter.aab":"Builds/CatHunter.apk", target=BuildTarget.Android, options=BuildOptions.None };
    var r=BuildPipeline.BuildPlayer(o); Debug.Log("CatHunter build: "+r.summary.result+" -> "+o.locationPathName);
    if(r.summary.result!=BuildResult.Succeeded) throw new System.Exception("فشل البناء"); }
}
}
#endif
