using UnityEngine;
namespace CatHunter {
public static class Mats {
  static Texture2D dot;
  static Shader Find(params string[] names){ foreach(var n in names){ var s=Shader.Find(n); if(s!=null) return s; } return Shader.Find("Sprites/Default"); }
  static void SetCol(Material m,Color c){ if(m.HasProperty("_BaseColor")) m.SetColor("_BaseColor",c); if(m.HasProperty("_Color")) m.SetColor("_Color",c); }
  public static Material Lit(Color c,float smooth=0.15f,Color? emit=null){
    var m=new Material(Find("Universal Render Pipeline/Lit","Standard")); SetCol(m,c);
    if(m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness",smooth);
    if(m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness",smooth);
    if(emit.HasValue){ m.EnableKeyword("_EMISSION"); m.SetColor("_EmissionColor",emit.Value); m.globalIlluminationFlags=MaterialGlobalIlluminationFlags.RealtimeEmissive; }
    return m; }
  public static Material Sprite(Color c){ var m=new Material(Shader.Find("Sprites/Default")); m.color=c; return m; }
  public static Texture2D Dot(){
    if(dot!=null) return dot; dot=new Texture2D(32,32,TextureFormat.RGBA32,false); dot.wrapMode=TextureWrapMode.Clamp;
    for(int y=0;y<32;y++) for(int x=0;x<32;x++){ float d=Vector2.Distance(new Vector2(x+0.5f,y+0.5f),new Vector2(16,16))/16f; float a=Mathf.Clamp01(1.4f-d*1.4f); dot.SetPixel(x,y,new Color(1,1,1,a)); }
    dot.Apply(); return dot; }
  public static UnityEngine.Sprite DotSprite(){ return UnityEngine.Sprite.Create(Dot(),new Rect(0,0,32,32),new Vector2(0.5f,0.5f)); }
}
}
