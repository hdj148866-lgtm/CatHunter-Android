using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
namespace CatHunter {
public enum GameState { Menu, Playing, Paused, Dialogue, Ending }
public static class Bootstrap {
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
  static void Init(){ if(GameManager.Instance==null) new GameObject("GameManager").AddComponent<GameManager>(); }
}
public class GameManager : MonoBehaviour {
  public static GameManager Instance;
  public GameState State=GameState.Menu;
  PlayerController player; Camera cam; UIManager ui; WorldBuilder world; readonly List<CatBehaviour> cats=new List<CatBehaviour>();
  int stage=0, mask; bool completed; float menuAngle; static int nativeW, nativeH;
  StageDef Def { get { return StageData.All[stage]; } }

  void Awake(){ Instance=this; DontDestroyOnLoad(gameObject); }
  void Start(){
    Screen.sleepTimeout=SleepTimeout.NeverSleep;
#if !UNITY_EDITOR
    Screen.orientation=ScreenOrientation.AutoRotation; Screen.autorotateToPortrait=false; Screen.autorotateToPortraitUpsideDown=false; Screen.autorotateToLandscapeLeft=true; Screen.autorotateToLandscapeRight=true;
#endif
    AudioManager.Create(transform);
    var cg=new GameObject("MainCamera"); cg.tag="MainCamera"; cam=cg.AddComponent<Camera>(); cg.AddComponent<AudioListener>(); cam.farClipPlane=400f; cam.nearClipPlane=0.2f; cam.fieldOfView=62f; cam.depth=10; cam.clearFlags=CameraClearFlags.Skybox; cam.backgroundColor=new Color(0.03f,0.05f,0.15f);
    world=new WorldBuilder(); world.Build(SaveData.Quality); world.SkyAnchor.target=cam.transform; ApplyQuality(SaveData.Quality);
    player=PlayerController.Create(cam,world.Spawn);
    var es=new GameObject("EventSystem"); es.AddComponent<EventSystem>(); es.AddComponent<StandaloneInputModule>(); es.transform.SetParent(transform);
    ui=gameObject.AddComponent<UIManager>(); ui.Init();
    ui.OnStart=()=>BeginGame(false); ui.OnContinue=()=>BeginGame(true); ui.OnHint=Hint; ui.OnInteract=Interact; ui.OnPause=Pause; ui.OnResume=Resume; ui.OnToMenu=ToMenu;
    ui.OnNextStage=NextStage; ui.OnKeepExploring=()=>{ ui.HideComplete(); SetPlaying(); }; ui.OnQuality=()=>ApplyQuality(SaveData.Quality);
    BuildCats(); ToMenu(); }

  void BuildCats(){ foreach(var c in cats) if(c) Destroy(c.gameObject); cats.Clear(); var cs=Def.cats; for(int i=0;i<cs.Length;i++) cats.Add(CatFactory.Create(i,cs[i],world.Dyn)); }
  public void ApplyQuality(int q){
    QualitySettings.shadowDistance=45f; QualitySettings.pixelLightCount=q==0?2:q==1?4:6; QualitySettings.antiAliasing=q==2?2:0; Application.targetFrameRate=q==0?30:60;
    if(world!=null && world.Moon!=null) world.Moon.shadows=q>=1?LightShadows.Soft:LightShadows.None;
#if !UNITY_EDITOR
    if(nativeW==0){ nativeW=Display.main.systemWidth; nativeH=Display.main.systemHeight; }
    float s=q==0?0.6f:q==1?0.8f:1f; Screen.SetResolution(Mathf.RoundToInt(nativeW*s),Mathf.RoundToInt(nativeH*s),true);
#endif
  }

  int Count(){ int n=0; for(int m=mask;m!=0;m&=m-1) n++; return n; }
  void BeginGame(bool cont){
    Time.timeScale=1f; if(!cont) SaveData.ResetStage(stage);
    mask=SaveData.FoundMask(stage); completed=SaveData.StageDone(stage); SaveData.MarkSaved();
    for(int i=0;i<cats.Count;i++) if((mask&(1<<i))!=0) cats[i].SetFound();
    world.Secret.SetActive(completed); ui.SetCount(Count(),cats.Count);
    player.Teleport(cont&&SaveData.HasPos?SaveData.Pos:world.Spawn); player.ResetCamera(0f); player.DriveCamera=true;
    ui.ShowHud(true);
    if(!cont){ State=GameState.Dialogue; player.ControlsEnabled=false; ui.ShowDialogue(Def.intro,SetPlaying); } else SetPlaying(); }
  void SetPlaying(){ State=GameState.Playing; player.ControlsEnabled=true; player.DriveCamera=true; }
  void Pause(){ if(State!=GameState.Playing) return; State=GameState.Paused; Time.timeScale=0f; player.ControlsEnabled=false; SaveData.SavePos(player.transform.position); ui.ShowPause(true); }
  void Resume(){ Time.timeScale=1f; ui.ShowPause(false); ui.ShowSettings(false); SetPlaying(); }
  void ToMenu(){ Time.timeScale=1f; if(State==GameState.Playing||State==GameState.Paused) SaveData.SavePos(player.transform.position);
    State=GameState.Menu; player.ControlsEnabled=false; player.DriveCamera=false; ui.ShowPause(false); ui.ShowMenu(SaveData.HasProgress); }

  CatBehaviour Nearest(out float dist){ CatBehaviour best=null; dist=float.MaxValue; var p=player.transform.position;
    foreach(var c in cats){ if(c.Found) continue; float d=Vector3.Distance(p,c.transform.position); if(d<dist){ dist=d; best=c; } } return best; }
  void Interact(){
    if(State!=GameState.Playing) return; float d; var c=Nearest(out d); if(c==null||d>4f) return;
    c.SetFound(); mask|=1<<c.id; SaveData.SetFoundMask(stage,mask); SaveData.SavePos(player.transform.position);
    ui.SetCount(Count(),cats.Count); Fx.Burst(c.transform.position+Vector3.up*0.5f,new Color(1f,0.85f,0.3f)); AudioManager.I.Meow(c.id); ui.Toast(c.line);
    if(Count()>=cats.Count) Invoke("CompleteStage",1.2f); }
  void CompleteStage(){
    completed=true; SaveData.SetStageDone(stage); world.Secret.SetActive(true); Fx.Burst(world.GatePos+Vector3.up*2f,new Color(0.6f,0.9f,1f),120); AudioManager.I.Success();
    State=GameState.Dialogue; player.ControlsEnabled=false;
    ui.ShowComplete("أعدتَ القطط العشر إلى القرية!\nظهر بابٌ مضيء في أقصى شمال القرية، خلف الجسر."); }
  void NextStage(){
    int n=stage+1; if(n<StageData.All.Length && StageData.All[n].implemented){ stage=n; BuildCats(); ui.HideComplete(); BeginGame(false); }
    else ui.Toast("المرحلة التالية قيد الإنشاء وستُضاف قريبًا"); }
  void Hint(){
    if(State!=GameState.Playing) return; float d; var c=Nearest(out d); if(c==null){ ui.Toast("لا توجد قطط مفقودة!"); return; }
    string heat=d<10f?"حار جدًا":d<25f?"دافئ":"بارد"; ui.Toast(c.hint+"\n("+heat+")",4f); }

  void Update(){
    if(State==GameState.Menu){ menuAngle+=Time.deltaTime*6f; float a=menuAngle*Mathf.Deg2Rad; cam.transform.position=new Vector3(Mathf.Sin(a)*46f,15f,Mathf.Cos(a)*46f); cam.transform.LookAt(new Vector3(0,3f,0)); return; }
    if(State==GameState.Playing){
      float d; var c=Nearest(out d); ui.ShowInteract(c!=null&&d<4f);
      if(completed){ var p=player.transform.position; var g=world.GatePos; if(new Vector2(p.x-g.x,p.z-g.z).magnitude<3f){ State=GameState.Ending; player.ControlsEnabled=false; SaveData.GameDone=true; AudioManager.I.Success(); ui.ShowEnding(string.Join("\n",StageData.Ending)); } }
#if UNITY_EDITOR || UNITY_STANDALONE
      if(Input.GetKeyDown(KeyCode.E)) Interact();
#endif
      if(Input.GetKeyDown(KeyCode.Escape)) Pause();
    } else if(State==GameState.Paused && Input.GetKeyDown(KeyCode.Escape)) Resume();
  }
  void OnApplicationPause(bool p){ if(p && player!=null){ if(State==GameState.Playing){ SaveData.SavePos(player.transform.position); Pause(); } } }
  void OnApplicationQuit(){ if(player!=null&&(State==GameState.Playing||State==GameState.Paused)) SaveData.SavePos(player.transform.position); }
}
}
