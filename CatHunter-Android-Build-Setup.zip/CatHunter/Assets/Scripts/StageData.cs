using UnityEngine;
namespace CatHunter {
public struct CatSpot { public Vector3 pos; public float yaw; public Color fur, accent; public string hint, line; }
public class StageDef { public string name; public string[] intro; public bool implemented; public CatSpot[] cats; }
// لإضافة مرحلة جديدة: أضف StageDef بقطط جديدة وفعّل implemented=true، ثم ابنِ بيئتها في WorldBuilder.
public static class StageData {
  static CatSpot C(float x,float y,float z,float yaw,Color fur,Color acc,string hint,string line){ return new CatSpot{ pos=new Vector3(x,y,z), yaw=yaw, fur=fur, accent=acc, hint=hint, line=line }; }
  static Color K(float r,float g,float b){ return new Color(r,g,b); }
  public static readonly StageDef[] All = {
    new StageDef{ name="المرحلة 1: القرية الليلية", implemented=true,
      intro=new[]{ "وصلتَ إلى قرية ليلية هادئة تحت سماءٍ تدور فيها النجوم.", "لكنّ القرية صامتة... فقد اختفت قططها العشر!", "ابحث على الأسطح وفي الحدائق وعند النهر، وأعدها واحدة تلو الأخرى." },
      cats=new[]{
        C(-13f,2.35f,10f,200f,K(0.9f,0.5f,0.15f),K(0.6f,0.3f,0.1f),"قطة تتأمل النجوم من سقف صغير ملاصق لمنزل.","مياو! كنت أراقب النجوم من فوق السطح."),
        C(-26f,0f,-20f,30f,K(0.08f,0.08f,0.1f),K(0.2f,0.2f,0.25f),"قطة تختبئ بين الزهور في حديقة بعيدة.","مياو! الزهور هنا تفوح برائحة الليل."),
        C(-4.5f,0f,-14f,90f,K(0.9f,0.9f,0.92f),K(0.7f,0.7f,0.75f),"قطة تراقب الماء عند ضفة النهر الغربية.","مياو! الماء يحمل ضوء القمر إلى الأحلام."),
        C(11.3f,0f,7.3f,160f,K(0.5f,0.5f,0.55f),K(0.3f,0.3f,0.35f),"قطة تنام خلف شجرة قريبة من الجسر.","مياو! ظننتُ أن الشجرة ستخفيني للأبد."),
        C(-16.4f,1.3f,-8.35f,180f,K(0.95f,0.85f,0.6f),K(0.8f,0.6f,0.3f),"قطة تنتظر الدفء عند نافذة مضيئة.","مياو! كانت النافذة تشبه نجمة صغيرة."),
        C(12f,0f,-6f,90f,K(0.45f,0.3f,0.2f),K(0.25f,0.15f,0.1f),"قطة صغيرة تحتمي تحت مقعد خشبي.","مياو! هذا المقعد أدفأ مكان في القرية."),
        C(3f,0.7f,1.95f,270f,K(0.4f,0.5f,0.65f),K(0.25f,0.3f,0.45f),"قطة تحرس الجسر من فوق السور.","مياو! من الجسر أرى القرية كلها."),
        C(16f,1f,-22f,45f,K(0.85f,0.35f,0.1f),K(0.95f,0.7f,0.3f),"قطة تجلس فوق صندوق قرب منزل شرقي.","مياو! الصندوق كان قلعتي السرية."),
        C(-11.4f,1f,-22f,120f,K(0.95f,0.95f,0.9f),K(0.55f,0.35f,0.15f),"قطة تحب حافة البئر الحجرية.","مياو! البئر يهمس بحكايات قديمة."),
        C(36.8f,0f,-1.6f,250f,K(0.2f,0.15f,0.12f),K(0.9f,0.85f,0.7f),"قطة تختبئ خلف المنزل البعيد في الشرق.","مياو! أخيرًا وجدتني، شكرًا لك!") } },
    new StageDef{ name="المرحلة 2: الحديقة والنهر (قريبًا)", implemented=false, cats=new CatSpot[0] },
    new StageDef{ name="المرحلة 3: الأزقة والأسطح (قريبًا)", implemented=false, cats=new CatSpot[0] },
    new StageDef{ name="المرحلة 4: المنطقة السرية (قريبًا)", implemented=false, cats=new CatSpot[0] } };
  public static readonly string[] Ending = { "عادت القطط العشر، وأضاءت القرية كلها.", "انفتح الباب السري، وفهمتَ أن النجوم تدور", "من أجل كل من يبحث بقلبه." };
}
}
