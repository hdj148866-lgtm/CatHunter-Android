using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
namespace CatHunter {
public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler {
  public RectTransform bg, handle; public float radius=110f;
  public void OnPointerDown(PointerEventData e){ OnDrag(e); }
  public void OnDrag(PointerEventData e){ Vector2 l; RectTransformUtility.ScreenPointToLocalPointInRectangle(bg,e.position,e.pressEventCamera,out l); var v=Vector2.ClampMagnitude(l/radius,1f); handle.anchoredPosition=v*radius; PlayerController.MoveInput=v; }
  public void OnPointerUp(PointerEventData e){ handle.anchoredPosition=Vector2.zero; PlayerController.MoveInput=Vector2.zero; }
}
public class LookPad : MonoBehaviour, IDragHandler { public void OnDrag(PointerEventData e){ PlayerController.LookDelta+=e.delta; } }

public class UIManager : MonoBehaviour {
  public Action OnStart, OnContinue, OnHint, OnInteract, OnPause, OnResume, OnToMenu, OnNextStage, OnKeepExploring, OnQuality;
  Font font; Sprite dot; RectTransform safe;
  GameObject menu, hud, pause, settings, complete, ending, dialogue, interactBtn; Button continueBtn;
  Text count, toast, dlgText, musicTxt, sfxTxt, qualTxt, completeTxt, endTxt; float toastT; string[] dlgLines; int dlgIdx; Action dlgDone;
  static readonly Color Navy=new Color(0.04f,0.07f,0.2f,0.92f), Gold=new Color(1f,0.85f,0.3f), BtnCol=new Color(0.15f,0.25f,0.6f,0.95f);

  GameObject Node(string n,Transform p,Vector2 amin,Vector2 amax){ var g=new GameObject(n,typeof(RectTransform)); g.transform.SetParent(p,false); var r=g.GetComponent<RectTransform>(); r.anchorMin=amin; r.anchorMax=amax; r.offsetMin=r.offsetMax=Vector2.zero; return g; }
  GameObject Fixed(string n,Transform p,Vector2 anchor,Vector2 pos,Vector2 size){ var g=new GameObject(n,typeof(RectTransform)); g.transform.SetParent(p,false); var r=g.GetComponent<RectTransform>(); r.anchorMin=r.anchorMax=r.pivot=anchor; r.anchoredPosition=pos; r.sizeDelta=size; return g; }
  Image Img(GameObject g,Color c,Sprite s=null){ var i=g.AddComponent<Image>(); i.color=c; i.sprite=s; return i; }
  Text Txt(Transform p,string s,int size,Color c,TextAnchor a,Vector2 amin,Vector2 amax){
    var g=Node("T",p,amin,amax); var t=g.AddComponent<Text>(); t.font=font; t.fontSize=size; t.color=c; t.alignment=a; t.horizontalOverflow=HorizontalWrapMode.Overflow; t.verticalOverflow=VerticalWrapMode.Overflow; t.raycastTarget=false; t.text=ArabicText.Fix(s); return t; }
  void Set(Text t,string s){ t.text=ArabicText.Fix(s); }
  Button MakeBtn(GameObject g,string label,int size,Action act){
    Img(g,BtnCol,null); var b=g.AddComponent<Button>(); b.onClick.AddListener(()=>{ if(AudioManager.I!=null) AudioManager.I.Click(); if(act!=null) act(); });
    Txt(g.transform,label,size,Color.white,TextAnchor.MiddleCenter,Vector2.zero,Vector2.one); return b; }
  Button RBtn(Transform p,string label,Vector2 amin,Vector2 amax,Action act){ return MakeBtn(Node("Btn",p,amin,amax),label,44,act); }
  Button CBtn(Transform p,string label,Vector2 anchor,Vector2 pos,float size,Action act){ var g=Fixed("CBtn",p,anchor,pos,new Vector2(size,size)); var b=MakeBtn(g,label,34,act); g.GetComponent<Image>().sprite=dot; return b; }
  GameObject Dim(string n,Color c){ var g=Node(n,safe,Vector2.zero,Vector2.one); Img(g,c); return g; }

  public void Init(){
    font=Font.CreateDynamicFontFromOSFont(new[]{ "Noto Sans Arabic","Noto Naskh Arabic","Roboto","Arial" },36); dot=Mats.DotSprite();
    var cg=new GameObject("Canvas"); cg.transform.SetParent(transform); var cv=cg.AddComponent<Canvas>(); cv.renderMode=RenderMode.ScreenSpaceOverlay; cv.sortingOrder=10;
    var sc=cg.AddComponent<CanvasScaler>(); sc.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; sc.referenceResolution=new Vector2(1920,1080); sc.matchWidthOrHeight=0.5f; cg.AddComponent<GraphicRaycaster>();
    var sg=new GameObject("Safe",typeof(RectTransform)); sg.transform.SetParent(cg.transform,false); safe=sg.GetComponent<RectTransform>();
    var sa=Screen.safeArea; safe.anchorMin=new Vector2(sa.xMin/Screen.width,sa.yMin/Screen.height); safe.anchorMax=new Vector2(sa.xMax/Screen.width,sa.yMax/Screen.height); safe.offsetMin=safe.offsetMax=Vector2.zero;
    BuildHud(); BuildMenu(); BuildPause(); BuildSettings(); BuildComplete(); BuildEnding(); BuildDialogue();
    var tg=Node("Toast",safe,new Vector2(0.15f,0.8f),new Vector2(0.85f,0.9f)); Img(tg,new Color(0,0,0,0.6f)); toast=Txt(tg.transform,"",38,Color.white,TextAnchor.MiddleCenter,Vector2.zero,Vector2.one); tg.SetActive(false); toast.transform.parent.gameObject.SetActive(false);
    HideAll(); }

  void BuildHud(){
    hud=Node("HUD",safe,Vector2.zero,Vector2.one);
    var lp=Node("LookPad",hud.transform,new Vector2(0.45f,0f),Vector2.one); Img(lp,new Color(0,0,0,0)); lp.AddComponent<LookPad>();
    var jb=Fixed("Joy",hud.transform,Vector2.zero,new Vector2(80,80),new Vector2(300,300)); Img(jb,new Color(1,1,1,0.15f),dot);
    var jh=Fixed("Handle",jb.transform,new Vector2(0.5f,0.5f),Vector2.zero,new Vector2(130,130)); Img(jh,new Color(1,1,1,0.45f),dot).raycastTarget=false;
    var vj=jb.AddComponent<VirtualJoystick>(); vj.bg=jb.GetComponent<RectTransform>(); vj.handle=jh.GetComponent<RectTransform>(); vj.radius=110f;
    var cp=Node("Counter",hud.transform,new Vector2(0.72f,0.9f),new Vector2(0.99f,0.99f)); Img(cp,new Color(0,0,0,0.5f)); count=Txt(cp.transform,"",44,Gold,TextAnchor.MiddleCenter,Vector2.zero,Vector2.one);
    var pb=Fixed("PauseBtn",hud.transform,new Vector2(0,1),new Vector2(20,-20),new Vector2(190,100)); MakeBtn(pb,"إيقاف",40,()=>{ if(OnPause!=null) OnPause(); });
    var hb=Fixed("HintBtn",hud.transform,new Vector2(0,1),new Vector2(230,-20),new Vector2(190,100)); MakeBtn(hb,"تلميح",40,()=>{ if(OnHint!=null) OnHint(); });
    CBtn(hud.transform,"قفز",new Vector2(1,0),new Vector2(-480,90),150f,()=>{ PlayerController.JumpQueued=true; });
    var ib=CBtn(hud.transform,"التقاط",new Vector2(1,0),new Vector2(-90,90),230f,()=>{ if(OnInteract!=null) OnInteract(); }); interactBtn=ib.gameObject; }

  void BuildMenu(){
    menu=Dim("Menu",new Color(0.02f,0.04f,0.15f,0.55f));
    Txt(menu.transform,"صائد القطط",110,Gold,TextAnchor.MiddleCenter,new Vector2(0.1f,0.72f),new Vector2(0.9f,0.92f));
    Txt(menu.transform,"ليلة النجوم  -  Cat Hunter: Starry Night",44,Color.white,TextAnchor.MiddleCenter,new Vector2(0.1f,0.64f),new Vector2(0.9f,0.72f));
    RBtn(menu.transform,"ابدأ اللعبة",new Vector2(0.35f,0.46f),new Vector2(0.65f,0.58f),()=>{ if(OnStart!=null) OnStart(); });
    continueBtn=RBtn(menu.transform,"متابعة",new Vector2(0.35f,0.32f),new Vector2(0.65f,0.44f),()=>{ if(OnContinue!=null) OnContinue(); });
    RBtn(menu.transform,"الإعدادات",new Vector2(0.35f,0.18f),new Vector2(0.65f,0.30f),()=>ShowSettings(true));
    RBtn(menu.transform,"خروج",new Vector2(0.35f,0.04f),new Vector2(0.65f,0.16f),()=>Application.Quit()); }

  void BuildPause(){
    pause=Dim("Pause",new Color(0,0,0,0.65f));
    Txt(pause.transform,"إيقاف مؤقت",80,Gold,TextAnchor.MiddleCenter,new Vector2(0.2f,0.72f),new Vector2(0.8f,0.9f));
    RBtn(pause.transform,"استئناف",new Vector2(0.35f,0.52f),new Vector2(0.65f,0.64f),()=>{ if(OnResume!=null) OnResume(); });
    RBtn(pause.transform,"الإعدادات",new Vector2(0.35f,0.36f),new Vector2(0.65f,0.48f),()=>ShowSettings(true));
    RBtn(pause.transform,"القائمة الرئيسية",new Vector2(0.35f,0.20f),new Vector2(0.65f,0.32f),()=>{ if(OnToMenu!=null) OnToMenu(); }); }

  void BuildSettings(){
    settings=Dim("Settings",Navy);
    Txt(settings.transform,"الإعدادات",80,Gold,TextAnchor.MiddleCenter,new Vector2(0.2f,0.78f),new Vector2(0.8f,0.94f));
    var m=RBtn(settings.transform,"",new Vector2(0.3f,0.6f),new Vector2(0.7f,0.72f),()=>{ SaveData.MusicOn=!SaveData.MusicOn; AudioManager.I.Apply(); RefreshSettings(); }); musicTxt=m.GetComponentInChildren<Text>();
    var s=RBtn(settings.transform,"",new Vector2(0.3f,0.45f),new Vector2(0.7f,0.57f),()=>{ SaveData.SfxOn=!SaveData.SfxOn; AudioManager.I.Apply(); RefreshSettings(); }); sfxTxt=s.GetComponentInChildren<Text>();
    var q=RBtn(settings.transform,"",new Vector2(0.3f,0.30f),new Vector2(0.7f,0.42f),()=>{ SaveData.Quality=(SaveData.Quality+1)%3; if(OnQuality!=null) OnQuality(); RefreshSettings(); }); qualTxt=q.GetComponentInChildren<Text>();
    RBtn(settings.transform,"رجوع",new Vector2(0.35f,0.12f),new Vector2(0.65f,0.24f),()=>ShowSettings(false)); }
  void RefreshSettings(){
    Set(musicTxt,"الموسيقى: "+(SaveData.MusicOn?"تعمل":"مكتومة")); Set(sfxTxt,"المؤثرات: "+(SaveData.SfxOn?"تعمل":"مكتومة"));
    Set(qualTxt,"جودة الرسوم: "+new[]{"منخفضة","متوسطة","عالية"}[SaveData.Quality]); }

  void BuildComplete(){
    complete=Dim("Complete",Navy);
    Txt(complete.transform,"نجحت المرحلة!",90,Gold,TextAnchor.MiddleCenter,new Vector2(0.1f,0.72f),new Vector2(0.9f,0.92f));
    completeTxt=Txt(complete.transform,"",46,Color.white,TextAnchor.MiddleCenter,new Vector2(0.1f,0.48f),new Vector2(0.9f,0.7f));
    RBtn(complete.transform,"متابعة الاستكشاف",new Vector2(0.2f,0.22f),new Vector2(0.48f,0.36f),()=>{ if(OnKeepExploring!=null) OnKeepExploring(); });
    RBtn(complete.transform,"المرحلة التالية",new Vector2(0.52f,0.22f),new Vector2(0.8f,0.36f),()=>{ if(OnNextStage!=null) OnNextStage(); }); }

  void BuildEnding(){
    ending=Dim("Ending",new Color(0.02f,0.04f,0.15f,0.95f));
    Txt(ending.transform,"اكتملت اللعبة",90,Gold,TextAnchor.MiddleCenter,new Vector2(0.1f,0.72f),new Vector2(0.9f,0.92f));
    endTxt=Txt(ending.transform,"",46,Color.white,TextAnchor.MiddleCenter,new Vector2(0.1f,0.4f),new Vector2(0.9f,0.7f));
    RBtn(ending.transform,"العودة إلى القائمة",new Vector2(0.33f,0.14f),new Vector2(0.67f,0.27f),()=>{ if(OnToMenu!=null) OnToMenu(); }); }

  void BuildDialogue(){
    dialogue=Node("Dialogue",safe,new Vector2(0.1f,0.04f),new Vector2(0.9f,0.3f)); Img(dialogue,new Color(0.02f,0.04f,0.15f,0.85f));
    var b=dialogue.AddComponent<Button>(); b.onClick.AddListener(NextLine);
    dlgText=Txt(dialogue.transform,"",42,Color.white,TextAnchor.MiddleCenter,new Vector2(0.03f,0.2f),new Vector2(0.97f,0.95f));
    Txt(dialogue.transform,"اضغط للمتابعة",28,new Color(1,1,1,0.6f),TextAnchor.LowerLeft,new Vector2(0.03f,0.02f),new Vector2(0.5f,0.25f)); }

  void HideAll(){ foreach(var g in new[]{ menu,hud,pause,settings,complete,ending,dialogue }) g.SetActive(false); }
  public void ShowMenu(bool hasSave){ HideAll(); menu.SetActive(true); continueBtn.interactable=hasSave; continueBtn.GetComponent<Image>().color=hasSave?BtnCol:new Color(0.2f,0.2f,0.25f,0.7f); }
  public void ShowHud(bool on){ if(on){ HideAll(); } hud.SetActive(on); if(!on) interactBtn.SetActive(false); }
  public void ShowInteract(bool on){ if(interactBtn.activeSelf!=on) interactBtn.SetActive(on); }
  public void SetCount(int a,int b){ Set(count,"القطط: "+a+"/"+b); }
  public void ShowPause(bool on){ pause.SetActive(on); }
  public void ShowSettings(bool on){ if(on) RefreshSettings(); settings.SetActive(on); }
  public void ShowComplete(string txt){ Set(completeTxt,txt); complete.SetActive(true); }
  public void HideComplete(){ complete.SetActive(false); }
  public void ShowEnding(string txt){ HideAll(); Set(endTxt,txt); ending.SetActive(true); }
  public void ShowDialogue(string[] lines,Action done){ dlgLines=lines; dlgIdx=0; dlgDone=done; Set(dlgText,lines[0]); dialogue.SetActive(true); }
  void NextLine(){ if(AudioManager.I!=null) AudioManager.I.Click(); dlgIdx++; if(dlgIdx>=dlgLines.Length){ dialogue.SetActive(false); if(dlgDone!=null) dlgDone(); } else Set(dlgText,dlgLines[dlgIdx]); }
  public void Toast(string s,float secs=3f){ Set(toast,s); toast.transform.parent.gameObject.SetActive(true); toastT=secs; }
  void Update(){ if(toastT>0f){ toastT-=Time.unscaledDeltaTime; if(toastT<=0f) toast.transform.parent.gameObject.SetActive(false); } }
}
}
