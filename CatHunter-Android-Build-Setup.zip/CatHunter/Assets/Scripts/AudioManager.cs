using UnityEngine;
namespace CatHunter {
// كل الأصوات تُولَّد برمجيًا (أصلية 100%، بلا ملفات محمية).
public class AudioManager : MonoBehaviour {
  public static AudioManager I;
  AudioSource music, sfx; AudioClip[] meows=new AudioClip[3]; AudioClip step, success, click, musicClip;
  public static AudioManager Create(Transform parent){ var go=new GameObject("Audio"); go.transform.SetParent(parent); return go.AddComponent<AudioManager>(); }
  static AudioClip Make(string n,float sec,System.Func<float,float> f){
    int sr=22050,len=(int)(sec*sr); var d=new float[len]; for(int i=0;i<len;i++) d[i]=Mathf.Clamp(f(i/(float)sr),-1f,1f);
    var c=AudioClip.Create(n,len,1,sr,false); c.SetData(d,0); return c; }
  void Awake(){
    I=this; music=gameObject.AddComponent<AudioSource>(); sfx=gameObject.AddComponent<AudioSource>(); music.loop=true; music.spatialBlend=0; sfx.spatialBlend=0;
    float[] pent={220f,261.63f,293.66f,329.63f,392f}; const float TP=2*Mathf.PI;
    musicClip=Make("music",16f,t=>{ int b=(int)t; float bt=t-b; float note=pent[(b*3+b/4)%5]*2f;
      float bell=Mathf.Sin(TP*note*t)*Mathf.Exp(-bt*3f)*(1f-Mathf.Exp(-bt*200f))*0.18f;
      float root=t<8f?110f:98f; float pad=(Mathf.Sin(TP*root*t)+0.6f*Mathf.Sin(TP*root*1.5f*t))*0.08f*(0.7f+0.3f*Mathf.Sin(TP*t/8f));
      return bell+pad; });
    float[] pitches={0.8f,1f,1.3f};
    for(int k=0;k<3;k++){ float p=pitches[k]; meows[k]=Make("meow"+k,0.7f,t=>{ float ph=TP*(500f*t+300f*0.7f/Mathf.PI*(1f-Mathf.Cos(Mathf.PI*t/0.7f)))*p;
      float env=Mathf.Pow(Mathf.Sin(Mathf.PI*t/0.7f),0.7f); return (Mathf.Sin(ph)+0.5f*Mathf.Sin(2*ph)+0.25f*Mathf.Sin(3*ph))*env*0.3f; }); }
    step=Make("step",0.12f,t=>(Random.value*2f-1f)*Mathf.Exp(-t*50f)*0.3f);
    click=Make("click",0.08f,t=>Mathf.Sin(TP*800f*t)*Mathf.Exp(-t*40f)*0.4f);
    float[] arp={523.25f,659.25f,783.99f,1046.5f};
    success=Make("success",1.0f,t=>{ int i=Mathf.Min(3,(int)(t/0.15f)); float lt=t-i*0.15f; return Mathf.Sin(TP*arp[i]*t)*Mathf.Exp(-lt*4f)*0.35f; });
    music.clip=musicClip; Apply(); music.Play(); }
  public void Apply(){ music.volume=SaveData.MusicOn?0.35f:0f; sfx.volume=SaveData.SfxOn?1f:0f; }
  public void Step(){ sfx.PlayOneShot(step,0.6f); }
  public void Click(){ sfx.PlayOneShot(click); }
  public void Meow(int id){ sfx.PlayOneShot(meows[id%3]); }
  public void Success(){ sfx.PlayOneShot(success); }
}
}
