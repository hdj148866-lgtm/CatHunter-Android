using UnityEngine;
namespace CatHunter {
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour {
  public static Vector2 MoveInput, LookDelta; public static bool JumpQueued;
  public bool ControlsEnabled, DriveCamera;
  CharacterController cc; Camera cam; Transform visual; float yaw, pitch=18f, vy, curDist=5.5f, stepT; const float Dist=5.5f;
  public static PlayerController Create(Camera cam,Vector3 pos){
    var go=new GameObject("Player"); go.layer=2; go.transform.position=pos;
    var c=go.AddComponent<CharacterController>(); c.height=1.8f; c.radius=0.35f; c.center=new Vector3(0,0.9f,0); c.stepOffset=0.4f; c.slopeLimit=50f; c.skinWidth=0.05f;
    var p=go.AddComponent<PlayerController>(); p.cam=cam; p.cc=c; p.BuildVisual(); return p; }
  void Part(PrimitiveType t,Vector3 lp,Vector3 ls,Color col){
    var g=GameObject.CreatePrimitive(t); Destroy(g.GetComponent<Collider>()); g.transform.SetParent(visual,false); g.transform.localPosition=lp; g.transform.localScale=ls; g.layer=2; g.GetComponent<Renderer>().material=Mats.Lit(col,0.2f); }
  void BuildVisual(){
    visual=new GameObject("Visual").transform; visual.SetParent(transform,false); visual.gameObject.layer=2;
    Part(PrimitiveType.Capsule,new Vector3(0,0.75f,0),new Vector3(0.7f,0.75f,0.7f),new Color(0.15f,0.25f,0.55f));
    Part(PrimitiveType.Sphere,new Vector3(0,1.7f,0),Vector3.one*0.42f,new Color(0.95f,0.8f,0.65f));
    Part(PrimitiveType.Cube,new Vector3(0,1.4f,0.05f),new Vector3(0.55f,0.14f,0.5f),new Color(1f,0.8f,0.25f)); }
  public void Teleport(Vector3 p){ cc.enabled=false; transform.position=p; cc.enabled=true; vy=0f; }
  public void ResetCamera(float y){ yaw=y; pitch=18f; curDist=Dist; }
  void Update(){
    if(!ControlsEnabled){ LookDelta=Vector2.zero; JumpQueued=false; return; }
    Vector2 mv=MoveInput;
#if UNITY_EDITOR || UNITY_STANDALONE
    var k=new Vector2(Input.GetAxisRaw("Horizontal"),Input.GetAxisRaw("Vertical")); if(k.sqrMagnitude>0.01f) mv=k;
    if(Input.GetMouseButton(1)) LookDelta+=new Vector2(Input.GetAxis("Mouse X"),Input.GetAxis("Mouse Y"))*12f;
    if(Input.GetKeyDown(KeyCode.Space)) JumpQueued=true;
#endif
    yaw+=LookDelta.x*0.12f; pitch=Mathf.Clamp(pitch-LookDelta.y*0.12f,-10f,60f); LookDelta=Vector2.zero;
    mv=Vector2.ClampMagnitude(mv,1f);
    Vector3 dir=Quaternion.Euler(0,yaw,0)*new Vector3(mv.x,0,mv.y);
    bool grounded=cc.isGrounded; if(grounded&&vy<0f) vy=-2f; if(JumpQueued&&grounded) vy=7f; JumpQueued=false; vy-=20f*Time.deltaTime;
    cc.Move((dir*4.6f+Vector3.up*vy)*Time.deltaTime);
    if(dir.sqrMagnitude>0.01f){
      visual.rotation=Quaternion.Slerp(visual.rotation,Quaternion.LookRotation(dir),12f*Time.deltaTime);
      if(grounded){ stepT-=Time.deltaTime; if(stepT<=0f){ stepT=0.38f; if(AudioManager.I!=null) AudioManager.I.Step(); } } }
  }
  void LateUpdate(){
    if(!DriveCamera||cam==null) return;
    Vector3 pivot=transform.position+Vector3.up*1.6f; Quaternion rot=Quaternion.Euler(pitch,yaw,0); Vector3 back=rot*Vector3.back; float want=Dist;
    if(Physics.SphereCast(pivot,0.25f,back,out var hit,Dist,~(1<<2),QueryTriggerInteraction.Ignore)) want=Mathf.Max(0.5f,hit.distance-0.05f);
    curDist=want<curDist?want:Mathf.Lerp(curDist,want,6f*Time.deltaTime);
    cam.transform.SetPositionAndRotation(pivot+back*curDist,rot); }
}
}
