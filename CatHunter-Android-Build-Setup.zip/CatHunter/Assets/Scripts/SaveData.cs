using UnityEngine;
namespace CatHunter {
public static class SaveData {
  public static int FoundMask(int stage){ return PlayerPrefs.GetInt("found_"+stage,0); }
  public static void SetFoundMask(int stage,int m){ PlayerPrefs.SetInt("found_"+stage,m); PlayerPrefs.Save(); }
  public static bool StageDone(int stage){ return PlayerPrefs.GetInt("done_"+stage,0)==1; }
  public static void SetStageDone(int stage){ PlayerPrefs.SetInt("done_"+stage,1); PlayerPrefs.Save(); }
  public static bool GameDone { get { return PlayerPrefs.GetInt("game_done",0)==1; } set { PlayerPrefs.SetInt("game_done",value?1:0); PlayerPrefs.Save(); } }
  public static bool HasProgress { get { return PlayerPrefs.GetInt("has_save",0)==1; } }
  public static void MarkSaved(){ PlayerPrefs.SetInt("has_save",1); }
  public static bool HasPos { get { return PlayerPrefs.HasKey("px"); } }
  public static Vector3 Pos { get { return new Vector3(PlayerPrefs.GetFloat("px"),PlayerPrefs.GetFloat("py")+0.1f,PlayerPrefs.GetFloat("pz")); } }
  public static void SavePos(Vector3 p){ PlayerPrefs.SetFloat("px",p.x); PlayerPrefs.SetFloat("py",p.y); PlayerPrefs.SetFloat("pz",p.z); MarkSaved(); PlayerPrefs.Save(); }
  public static void ResetStage(int stage){ PlayerPrefs.DeleteKey("found_"+stage); PlayerPrefs.DeleteKey("done_"+stage); PlayerPrefs.DeleteKey("px"); PlayerPrefs.DeleteKey("py"); PlayerPrefs.DeleteKey("pz"); PlayerPrefs.SetInt("game_done",0); PlayerPrefs.Save(); }
  public static bool MusicOn { get { return PlayerPrefs.GetInt("music",1)==1; } set { PlayerPrefs.SetInt("music",value?1:0); PlayerPrefs.Save(); } }
  public static bool SfxOn { get { return PlayerPrefs.GetInt("sfx",1)==1; } set { PlayerPrefs.SetInt("sfx",value?1:0); PlayerPrefs.Save(); } }
  public static int Quality { get { return PlayerPrefs.GetInt("quality",1); } set { PlayerPrefs.SetInt("quality",value); PlayerPrefs.Save(); } }
}
}
