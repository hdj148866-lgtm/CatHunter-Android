using System.Collections.Generic;
namespace CatHunter {
// يشكّل الحروف العربية ويعكس الاتجاه لعرض صحيح في Text القديم (Unity UI) الذي لا يدعم RTL.
// ملاحظة: يفضَّل لاحقًا استبداله بمكتبة RTLTMPro المجانية مع TextMeshPro.
public static class ArabicText {
  static readonly Dictionary<char,int[]> F = Build();
  static Dictionary<char,int[]> Build(){
    var d=new Dictionary<char,int[]>();
    void R(char c,int iso,int fin){ d[c]=new[]{iso,fin}; }
    void D(char c,int iso){ d[c]=new[]{iso,iso+1,iso+2,iso+3}; }
    R('\u0621',0xFE80,0xFE80); R('\u0622',0xFE81,0xFE82); R('\u0623',0xFE83,0xFE84); R('\u0624',0xFE85,0xFE86);
    R('\u0625',0xFE87,0xFE88); D('\u0626',0xFE89); R('\u0627',0xFE8D,0xFE8E); D('\u0628',0xFE8F); R('\u0629',0xFE93,0xFE94);
    D('\u062A',0xFE95); D('\u062B',0xFE99); D('\u062C',0xFE9D); D('\u062D',0xFEA1); D('\u062E',0xFEA5);
    R('\u062F',0xFEA9,0xFEAA); R('\u0630',0xFEAB,0xFEAC); R('\u0631',0xFEAD,0xFEAE); R('\u0632',0xFEAF,0xFEB0);
    D('\u0633',0xFEB1); D('\u0634',0xFEB5); D('\u0635',0xFEB9); D('\u0636',0xFEBD); D('\u0637',0xFEC1); D('\u0638',0xFEC5);
    D('\u0639',0xFEC9); D('\u063A',0xFECD); D('\u0641',0xFED1); D('\u0642',0xFED5); D('\u0643',0xFED9); D('\u0644',0xFEDD);
    D('\u0645',0xFEE1); D('\u0646',0xFEE5); D('\u0647',0xFEE9); R('\u0648',0xFEED,0xFEEE); R('\u0649',0xFEEF,0xFEF0); D('\u064A',0xFEF1);
    return d; }
  static bool LamAlef(char a,out int iso,out int fin){
    switch(a){ case '\u0622': iso=0xFEF5; fin=0xFEF6; return true; case '\u0623': iso=0xFEF7; fin=0xFEF8; return true;
      case '\u0625': iso=0xFEF9; fin=0xFEFA; return true; case '\u0627': iso=0xFEFB; fin=0xFEFC; return true; }
    iso=fin=0; return false; }
  static bool PrevJoins(string t,int i){ return i>0 && F.TryGetValue(t[i-1],out var g) && g.Length==4; }
  static bool IsLtr(char c){ return c<128 && (char.IsLetterOrDigit(c) || c=='/'); }
  public static string Fix(string s){
    if(string.IsNullOrEmpty(s)) return s; var ls=s.Split('\n');
    for(int i=0;i<ls.Length;i++) ls[i]=Line(ls[i]); return string.Join("\n",ls); }
  static string Line(string t){
    bool any=false; foreach(var c in t) if(c>=0x0600&&c<=0x06FF){ any=true; break; } if(!any) return t;
    var o=new List<char>(t.Length);
    for(int i=0;i<t.Length;i++){
      char c=t[i];
      if(!F.TryGetValue(c,out var f)){ o.Add(c); continue; }
      if(c=='\u0644' && i+1<t.Length && LamAlef(t[i+1],out int iso,out int fin)){ o.Add((char)(PrevJoins(t,i)?fin:iso)); i++; continue; }
      bool prev=PrevJoins(t,i);
      int form;
      if(f.Length==4){ bool next=i+1<t.Length && F.ContainsKey(t[i+1]) && t[i+1]!='\u0621'; form=prev&&next?3:prev?1:next?2:0; }
      else form=prev?1:0;
      o.Add((char)f[form]);
    }
    o.Reverse();
    for(int i=0;i<o.Count;){ if(IsLtr(o[i])){ int j=i; while(j<o.Count&&IsLtr(o[j])) j++; o.Reverse(i,j-i); i=j; } else i++; }
    for(int i=0;i<o.Count;i++){ if(o[i]=='(') o[i]=')'; else if(o[i]==')') o[i]='('; }
    return new string(o.ToArray()); }
}
}
