using UnityEngine;
namespace CatHunter {
public class CatBehaviour : MonoBehaviour {
  public int id; public string hint, line; public bool Found;
  Transform body, tail, earL, earR, star; Quaternion earLBase; Vector3 bodyScale; float ph, nextTwitch, twitchT;
  public void Setup(Transform b,Transform t,Transform el,Transform er){ body=b; tail=t; earL=el; earR=er; earLBase=el.localRotation; bodyScale=b.localScale; ph=Random.value*10f; nextTwitch=Time.time+Random.Range(2f,6f); }
  void Update(){
    float t=Time.time+ph;
    body.localScale=new Vector3(bodyScale.x,bodyScale.y*(1f+0.05f*Mathf.Sin(t*2.2f)),bodyScale.z);
    tail.localRotation=Quaternion.Euler(-50f,Mathf.Sin(t*2.6f)*30f,0f);
    if(Time.time>nextTwitch){ twitchT=0.25f; nextTwitch=Time.time+Random.Range(2f,6f); }
    if(twitchT>0f){ twitchT-=Time.deltaTime; float a=Mathf.Sin(twitchT*40f)*15f; earL.localRotation=earLBase*Quaternion.Euler(0,0,a); } else earL.localRotation=earLBase;
    if(star!=null){ star.localPosition=new Vector3(0,1.15f+0.08f*Mathf.Sin(Time.time*3f),0); star.Rotate(0,120f*Time.deltaTime,0); }
  }
  public void SetFound(){
    if(Found) return; Found=true;
    var s=GameObject.CreatePrimitive(PrimitiveType.Sphere); Destroy(s.GetComponent<Collider>()); s.transform.SetParent(transform,false); s.transform.localScale=Vector3.one*0.12f;
    s.GetComponent<Renderer>().material=Mats.Lit(new Color(1f,0.85f,0.3f),0.5f,new Color(1f,0.8f,0.2f)*2f); star=s.transform; }
}
public static class CatFactory {
  static Transform P(Transform parent,PrimitiveType t,Vector3 lp,Vector3 ls,Material m,Vector3? euler=null){
    var g=GameObject.CreatePrimitive(t); Object.Destroy(g.GetComponent<Collider>()); g.transform.SetParent(parent,false);
    g.transform.localPosition=lp; g.transform.localScale=ls; if(euler.HasValue) g.transform.localEulerAngles=euler.Value; g.GetComponent<Renderer>().sharedMaterial=m; return g.transform; }
  public static CatBehaviour Create(int id,CatSpot s,Transform parent){
    var root=new GameObject("Cat_"+id); root.transform.SetParent(parent); root.transform.position=s.pos; root.transform.rotation=Quaternion.Euler(0,s.yaw,0); root.transform.localScale=Vector3.one*1.2f;
    var fur=Mats.Lit(s.fur,0.2f); var acc=Mats.Lit(s.accent,0.2f); var eye=Mats.Lit(Color.black,0.8f,new Color(0.6f,1f,0.3f)*1.5f); var nose=Mats.Lit(new Color(0.9f,0.5f,0.55f),0.3f);
    var body=P(root.transform,PrimitiveType.Sphere,new Vector3(0,0.24f,0),new Vector3(0.5f,0.34f,0.72f),fur);
    var head=P(root.transform,PrimitiveType.Sphere,new Vector3(0,0.42f,0.34f),Vector3.one*0.3f,fur);
    var earL=P(head,PrimitiveType.Cube,new Vector3(-0.32f,0.42f,0f),new Vector3(0.28f,0.4f,0.12f),acc,new Vector3(0,0,35f));
    var earR=P(head,PrimitiveType.Cube,new Vector3(0.32f,0.42f,0f),new Vector3(0.28f,0.4f,0.12f),acc,new Vector3(0,0,-35f));
    P(head,PrimitiveType.Sphere,new Vector3(-0.22f,0.1f,0.42f),Vector3.one*0.2f,eye); P(head,PrimitiveType.Sphere,new Vector3(0.22f,0.1f,0.42f),Vector3.one*0.2f,eye);
    P(head,PrimitiveType.Sphere,new Vector3(0,-0.1f,0.48f),Vector3.one*0.12f,nose);
    P(root.transform,PrimitiveType.Cube,new Vector3(0,0.41f,-0.05f),new Vector3(0.3f,0.03f,0.1f),acc); P(root.transform,PrimitiveType.Cube,new Vector3(0,0.4f,-0.22f),new Vector3(0.28f,0.03f,0.1f),acc);
    P(root.transform,PrimitiveType.Sphere,new Vector3(-0.12f,0.07f,0.25f),new Vector3(0.12f,0.14f,0.2f),fur); P(root.transform,PrimitiveType.Sphere,new Vector3(0.12f,0.07f,0.25f),new Vector3(0.12f,0.14f,0.2f),fur);
    var tailPivot=new GameObject("TailPivot").transform; tailPivot.SetParent(root.transform,false); tailPivot.localPosition=new Vector3(0,0.25f,-0.33f);
    P(tailPivot,PrimitiveType.Capsule,new Vector3(0,0.2f,0),new Vector3(0.08f,0.2f,0.08f),acc);
    var cat=root.AddComponent<CatBehaviour>(); cat.id=id; cat.hint=s.hint; cat.line=s.line; cat.Setup(body,tailPivot,earL,earR); return cat; }
}
}
