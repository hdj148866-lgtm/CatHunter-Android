using UnityEngine;
namespace CatHunter {
public class Spin : MonoBehaviour { public Vector3 axis=Vector3.forward; public float speed=10f; void Update(){ transform.Rotate(axis,speed*Time.deltaTime,Space.Self); } }
public class Follow : MonoBehaviour { public Transform target; void LateUpdate(){ if(target) transform.position=target.position; } }
public class WaterShimmer : MonoBehaviour {
  Material m; void Start(){ m=GetComponent<Renderer>().material; }
  void Update(){ if(m==null||!m.HasProperty("_EmissionColor")) return; m.SetColor("_EmissionColor",new Color(0.05f,0.15f,0.4f)*(0.4f+0.25f*Mathf.Sin(Time.time*1.3f))); } }
public class TempFx : MonoBehaviour {
  public float life=1.2f; Light l; float t,i0;
  void Start(){ l=GetComponent<Light>(); if(l) i0=l.intensity; Destroy(gameObject,life); }
  void Update(){ t+=Time.deltaTime; if(l) l.intensity=i0*Mathf.Max(0f,1f-t/life); } }
public static class Fx {
  public static void Burst(Vector3 pos,Color c,int count=60){
    var go=new GameObject("Burst"); go.transform.position=pos; var ps=go.AddComponent<ParticleSystem>();
    ps.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);
    var main=ps.main; main.duration=0.5f; main.loop=false; main.startLifetime=1.1f; main.startSpeed=3f; main.startSize=0.2f; main.startColor=c; main.playOnAwake=false; main.gravityModifier=-0.05f;
    var em=ps.emission; em.rateOverTime=0; em.SetBursts(new[]{ new ParticleSystem.Burst(0f,(short)count) });
    var sh=ps.shape; sh.shapeType=ParticleSystemShapeType.Sphere; sh.radius=0.3f;
    var col=ps.colorOverLifetime; col.enabled=true; var g=new Gradient();
    g.SetKeys(new[]{ new GradientColorKey(c,0f), new GradientColorKey(c,1f) }, new[]{ new GradientAlphaKey(1f,0f), new GradientAlphaKey(0f,1f) }); col.color=g;
    var r=go.GetComponent<ParticleSystemRenderer>(); var m=Mats.Sprite(Color.white); m.mainTexture=Mats.Dot(); r.material=m;
    ps.Play(); Object.Destroy(go,2.5f);
    var lg=new GameObject("Flash"); lg.transform.position=pos+Vector3.up*0.5f; var l=lg.AddComponent<Light>(); l.color=c; l.intensity=3f; l.range=9f; lg.AddComponent<TempFx>(); }
}
}
