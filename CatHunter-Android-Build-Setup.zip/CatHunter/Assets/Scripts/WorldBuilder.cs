using System.Collections.Generic;
using UnityEngine;
namespace CatHunter {
public class WorldBuilder {
  public Transform Root, Dyn; public Follow SkyAnchor; public Light Moon; public GameObject Secret;
  public Vector3 Spawn=new Vector3(-8f,0.3f,-36f), GatePos=new Vector3(0f,0f,40f);
  readonly Dictionary<string,Material> cache=new Dictionary<string,Material>();
  Material M(Color c,float s=0.15f,float em=0f){ string k=c+"|"+s+"|"+em; if(!cache.TryGetValue(k,out var m)){ m=Mats.Lit(c,s,em>0f?(Color?)(c*em):null); cache[k]=m; } return m; }
  GameObject Prim(Transform p,PrimitiveType t,Vector3 lp,Vector3 ls,Material m,bool col=true,Vector3? euler=null){
    var g=GameObject.CreatePrimitive(t); if(!col) Object.Destroy(g.GetComponent<Collider>()); g.transform.SetParent(p,false);
    g.transform.localPosition=lp; g.transform.localScale=ls; if(euler.HasValue) g.transform.localEulerAngles=euler.Value; g.GetComponent<Renderer>().sharedMaterial=m; return g; }
  GameObject Box(Transform p,Vector3 lp,Vector3 ls,Material m,bool col=true,Vector3? e=null){ return Prim(p,PrimitiveType.Cube,lp,ls,m,col,e); }
  Transform Group(string n,Vector3 pos,float yaw){ var g=new GameObject(n).transform; g.SetParent(Root,false); g.localPosition=pos; g.localEulerAngles=new Vector3(0,yaw,0); return g; }

  public void Build(int quality){
    Root=new GameObject("StaticWorld").transform; Dyn=new GameObject("DynamicWorld").transform;
    RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat; RenderSettings.ambientLight=new Color(0.16f,0.2f,0.38f);
    RenderSettings.fog=true; RenderSettings.fogMode=FogMode.ExponentialSquared; RenderSettings.fogDensity=0.008f; RenderSettings.fogColor=new Color(0.05f,0.08f,0.22f);
    var sky=Shader.Find("Skybox/Procedural");
    if(sky!=null){ var sm=new Material(sky); sm.SetColor("_SkyTint",new Color(0.05f,0.1f,0.35f)); sm.SetColor("_GroundColor",new Color(0.03f,0.05f,0.15f)); sm.SetFloat("_Exposure",0.55f); sm.SetFloat("_SunSize",0f); sm.SetFloat("_AtmosphereThickness",0.4f); RenderSettings.skybox=sm; }
    var lg=new GameObject("MoonLight"); lg.transform.rotation=Quaternion.Euler(50,-30,0); Moon=lg.AddComponent<Light>(); Moon.type=LightType.Directional; Moon.color=new Color(0.5f,0.6f,1f); Moon.intensity=0.9f; Moon.shadows=quality>=1?LightShadows.Soft:LightShadows.None;

    var grass=M(new Color(0.1f,0.22f,0.22f),0.05f); var sand=M(new Color(0.42f,0.38f,0.32f),0.1f); var stone=M(new Color(0.42f,0.4f,0.46f),0.1f);
    Box(Root,new Vector3(-27,-0.5f,0),new Vector3(46,1,100),grass); Box(Root,new Vector3(27,-0.5f,0),new Vector3(46,1,100),grass);
    Box(Root,new Vector3(0,-0.75f,0),new Vector3(8,1,100),M(new Color(0.15f,0.15f,0.2f)));
    var water=Prim(Dyn,PrimitiveType.Cube,new Vector3(0,-0.12f,0),new Vector3(8,0.02f,100),Mats.Lit(new Color(0.05f,0.12f,0.3f),0.95f,new Color(0.05f,0.15f,0.4f)*0.5f),false); water.AddComponent<WaterShimmer>();
    foreach(var w in new[]{ new Vector3(-50,5,0),new Vector3(50,5,0) }){ var b=new GameObject("Wall").AddComponent<BoxCollider>(); b.transform.SetParent(Root,false); b.transform.localPosition=w; b.size=new Vector3(1,10,100); }
    foreach(var w in new[]{ new Vector3(0,5,-50),new Vector3(0,5,50) }){ var b=new GameObject("Wall").AddComponent<BoxCollider>(); b.transform.SetParent(Root,false); b.transform.localPosition=w; b.size=new Vector3(100,10,1); }

    // جسر
    var wood=M(new Color(0.35f,0.22f,0.12f),0.1f);
    Box(Root,new Vector3(0,-0.02f,0),new Vector3(9,0.2f,4),wood);
    Box(Root,new Vector3(0,0.4f,1.95f),new Vector3(9,0.6f,0.15f),wood); Box(Root,new Vector3(0,0.4f,-1.95f),new Vector3(9,0.6f,0.15f),wood);
    // طرق
    Box(Root,new Vector3(-27,0.01f,0),new Vector3(46,0.02f,3),sand,false); Box(Root,new Vector3(27,0.01f,0),new Vector3(46,0.02f,3),sand,false);
    Box(Root,new Vector3(-8,0.01f,0),new Vector3(3,0.02f,98),sand,false); Box(Root,new Vector3(8,0.01f,0),new Vector3(3,0.02f,98),sand,false);

    // منازل: x,z,w,h,d,yaw,annex
    var houses=new[]{ new[]{-18f,10f,7f,4f,6f,0f,1f}, new[]{-18f,-12f,6f,3.6f,7f,0f,0f}, new[]{-34f,2f,8f,4.5f,6f,0f,0f}, new[]{20f,14f,7f,4f,6f,0f,0f},
      new[]{20f,-14f,6f,3.8f,6f,0f,0f}, new[]{32f,2f,8f,4.2f,6f,0f,0f}, new[]{-30f,30f,6f,3.5f,6f,0f,0f}, new[]{30f,-30f,6f,3.8f,6f,0f,0f} };
    var wallCols=new[]{ new Color(0.42f,0.4f,0.46f), new Color(0.5f,0.45f,0.36f), new Color(0.38f,0.42f,0.5f) };
    var roofCols=new[]{ new Color(0.2f,0.25f,0.5f), new Color(0.55f,0.3f,0.2f), new Color(0.25f,0.35f,0.45f) };
    int hi=0; var win=M(new Color(1f,0.72f,0.3f),0.3f,1.6f);
    foreach(var h in houses){
      var g=Group("House"+hi,new Vector3(h[0],0,h[1]),h[5]); float w=h[2],ht=h[3],d=h[4]; var wm=M(wallCols[hi%3],0.1f); var rm=M(roofCols[hi%3],0.2f);
      Box(g,new Vector3(0,ht/2f,0),new Vector3(w,ht,d),wm);
      float a=30f*Mathf.Deg2Rad; float len=(w/2f)/Mathf.Cos(a)+0.4f; float ry=ht+(w/4f)*Mathf.Tan(a);
      Box(g,new Vector3(-w/4f,ry,0),new Vector3(len,0.25f,d+0.8f),rm,true,new Vector3(0,0,30)); Box(g,new Vector3(w/4f,ry,0),new Vector3(len,0.25f,d+0.8f),rm,true,new Vector3(0,0,-30));
      Box(g,new Vector3(w/2f-1f,ht+1.2f,-d/4f),new Vector3(0.6f,1.6f,0.6f),stone);
      Box(g,new Vector3(0,1.0f,d/2f+0.02f),new Vector3(1.1f,2f,0.1f),wood,false);
      foreach(float sx in new[]{-w/4f-0.2f,w/4f+0.2f}){ Box(g,new Vector3(sx,ht*0.5f,d/2f+0.03f),new Vector3(0.9f,1.1f,0.06f),win,false); Box(g,new Vector3(sx,ht*0.5f-0.62f,d/2f+0.15f),new Vector3(1.2f,0.1f,0.3f),stone); Box(g,new Vector3(sx,ht*0.5f,-d/2f-0.03f),new Vector3(0.9f,1.1f,0.06f),win,false); }
      if(h[6]>0f){ Box(g,new Vector3(w/2f+1.5f,1.1f,0),new Vector3(3f,2.2f,3f),wm); Box(g,new Vector3(w/2f+1.5f,2.25f,0),new Vector3(3.4f,0.15f,3.4f),rm); }
      hi++; }
    // أشجار: x,z,cypress
    var trees=new[]{ new[]{-5.5f,-26f,1f},new[]{5.5f,-28f,1f},new[]{-5.5f,24f,1f},new[]{5.5f,26f,1f},new[]{-40f,-10f,1f},new[]{40f,-12f,1f},new[]{-26f,-6f,1f},
      new[]{11f,6f,0f},new[]{-24f,18f,0f},new[]{26f,-6f,0f},new[]{-26f,-30f,0f},new[]{26f,30f,0f},new[]{14f,-34f,0f},new[]{-10f,34f,0f},new[]{-44f,20f,0f},new[]{44f,18f,0f},new[]{-40f,38f,1f},new[]{40f,40f,1f} };
    var trunk=M(new Color(0.25f,0.15f,0.1f)); var cyp=M(new Color(0.05f,0.18f,0.14f),0.05f); var leaf=M(new Color(0.1f,0.3f,0.25f),0.05f);
    foreach(var t in trees){ var g=Group("Tree",new Vector3(t[0],0,t[1]),0);
      Prim(g,PrimitiveType.Cylinder,new Vector3(0,1.4f,0),new Vector3(0.5f,1.4f,0.5f),trunk);
      if(t[2]>0f) Prim(g,PrimitiveType.Capsule,new Vector3(0,4.5f,0),new Vector3(1.8f,3.5f,1.8f),cyp,false);
      else { Prim(g,PrimitiveType.Sphere,new Vector3(0,4f,0),new Vector3(3.4f,3.2f,3.4f),leaf,false); Prim(g,PrimitiveType.Sphere,new Vector3(0.9f,3.4f,0.5f),new Vector3(2.4f,2.2f,2.4f),leaf,false); } }
    // فوانيس
    var lamp=M(new Color(1f,0.8f,0.35f),0.3f,2.2f); var iron=M(new Color(0.08f,0.08f,0.1f));
    var lanterns=new[]{ new Vector2(4.3f,-2.2f),new Vector2(-4.3f,2.2f),new Vector2(-6.6f,-30f),new Vector2(6.6f,-30f),new Vector2(-6.6f,-15f),new Vector2(6.6f,-15f),new Vector2(-6.6f,14f),new Vector2(6.6f,14f),new Vector2(-6.6f,30f),new Vector2(6.6f,30f) };
    int maxLights=quality==0?3:quality==1?5:8; int li=0;
    foreach(var p in lanterns){ var g=Group("Lantern",new Vector3(p.x,0,p.y),0); Prim(g,PrimitiveType.Cylinder,new Vector3(0,1.2f,0),new Vector3(0.12f,1.2f,0.12f),iron); Prim(g,PrimitiveType.Sphere,new Vector3(0,2.6f,0),Vector3.one*0.4f,lamp,false);
      if(li++<maxLights){ var l=new GameObject("LL").AddComponent<Light>(); l.transform.SetParent(Dyn,false); l.transform.position=new Vector3(p.x,2.6f,p.y); l.color=new Color(1f,0.75f,0.35f); l.range=12f; l.intensity=1.3f; l.shadows=LightShadows.None; } }
    // أزهار
    var fcols=new[]{ new Color(1f,0.85f,0.2f), new Color(1f,0.5f,0.2f), new Color(1f,0.5f,0.7f), new Color(0.6f,0.8f,1f) };
    foreach(var c in new[]{ new Vector2(-26f,-20f), new Vector2(24f,-24f), new Vector2(-24f,26f) }){ Random.InitState((int)(c.x*13+c.y)); var g=Group("Garden",new Vector3(c.x,0,c.y),0);
      for(int i=0;i<22;i++){ var o=Random.insideUnitCircle*3f; Prim(g,PrimitiveType.Sphere,new Vector3(o.x,0.15f,o.y),Vector3.one*0.2f,M(fcols[i%4],0.2f,0.4f),false); } }
    // قصب عند النهر
    { var g=Group("Reeds",new Vector3(-4.6f,0,-14f),0); Random.InitState(7); for(int i=0;i<12;i++){ var o=Random.insideUnitCircle*1.1f; float hh=Random.Range(0.5f,1.1f); Prim(g,PrimitiveType.Cylinder,new Vector3(o.x,hh,o.y),new Vector3(0.04f,hh,0.04f),M(new Color(0.2f,0.4f,0.25f)),false); } }
    // مقعد
    { var g=Group("Bench",new Vector3(12f,0,-6f),90f); Box(g,new Vector3(0,0.65f,0),new Vector3(2f,0.12f,0.6f),wood); Box(g,new Vector3(0,1f,-0.27f),new Vector3(2f,0.5f,0.08f),wood);
      foreach(var lx in new[]{-0.9f,0.9f}) foreach(var lz in new[]{-0.22f,0.22f}) Box(g,new Vector3(lx,0.32f,lz),new Vector3(0.1f,0.64f,0.1f),wood); }
    // صناديق وبئر
    Box(Root,new Vector3(16f,0.5f,-22f),Vector3.one,wood); Box(Root,new Vector3(17.3f,0.5f,-22.4f),Vector3.one,wood); Box(Root,new Vector3(17.3f,1.5f,-22.4f),Vector3.one*0.9f,wood);
    Prim(Root,PrimitiveType.Cylinder,new Vector3(-12f,0.5f,-22f),new Vector3(1.6f,0.5f,1.6f),stone);

    BuildSky(); BuildSecret();
    StaticBatchingUtility.Combine(Root.gameObject);
  }

  void BuildSky(){
    var a=new GameObject("SkyAnchor"); SkyAnchor=a.AddComponent<Follow>(); a.transform.SetParent(Dyn);
    // نجوم
    var sg=new GameObject("Stars"); sg.transform.SetParent(a.transform,false); var ps=sg.AddComponent<ParticleSystem>(); ps.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);
    var main=ps.main; main.loop=false; main.playOnAwake=false; main.simulationSpace=ParticleSystemSimulationSpace.Local; main.maxParticles=800; var em=ps.emission; em.enabled=false; var shp=ps.shape; shp.enabled=false;
    var r=sg.GetComponent<ParticleSystemRenderer>(); var sm=Mats.Sprite(Color.white); sm.mainTexture=Mats.Dot(); r.material=sm;
    Random.InitState(42); ps.Play();
    for(int i=0;i<650;i++){ var dir=Random.onUnitSphere; dir.y=Mathf.Abs(dir.y)*0.9f+0.05f; dir.Normalize();
      var ep=new ParticleSystem.EmitParams(); ep.position=dir*170f; ep.velocity=Vector3.zero; ep.startLifetime=1e8f; ep.startSize=Random.Range(0.8f,2.6f); ep.startColor=Color.Lerp(new Color(1f,1f,0.85f),new Color(0.8f,0.9f,1f),Random.value); ps.Emit(ep,1); }
    // قمر
    var moon=GameObject.CreatePrimitive(PrimitiveType.Quad); Object.Destroy(moon.GetComponent<Collider>()); moon.transform.SetParent(a.transform,false); moon.transform.localPosition=new Vector3(60,75,100); moon.transform.localScale=Vector3.one*16f; moon.transform.LookAt(a.transform.position+(a.transform.position-moon.transform.position));
    var mm=Mats.Sprite(new Color(1f,0.95f,0.7f)); mm.mainTexture=Mats.Dot(); moon.GetComponent<Renderer>().material=mm;
    var halo=GameObject.CreatePrimitive(PrimitiveType.Quad); Object.Destroy(halo.GetComponent<Collider>()); halo.transform.SetParent(a.transform,false); halo.transform.localPosition=new Vector3(60,75,101); halo.transform.localScale=Vector3.one*50f; halo.transform.rotation=moon.transform.rotation;
    var hm=Mats.Sprite(new Color(1f,0.9f,0.5f,0.25f)); hm.mainTexture=Mats.Dot(); halo.GetComponent<Renderer>().material=hm;
    // دوامات سماوية
    MakeSwirl(a.transform,new Vector3(-80,60,90),14f,22f); MakeSwirl(a.transform,new Vector3(20,95,110),18f,-16f); MakeSwirl(a.transform,new Vector3(95,50,40),12f,26f);
  }
  GameObject MakeSwirl(Transform parent,Vector3 lp,float scale,float speed){
    var go=new GameObject("Swirl"); go.transform.SetParent(parent,false); go.transform.localPosition=lp; go.transform.LookAt(parent.position);
    var lr=go.AddComponent<LineRenderer>(); lr.useWorldSpace=false; int n=150; lr.positionCount=n;
    for(int i=0;i<n;i++){ float th=i*0.17f; float rr=scale*th*0.075f; lr.SetPosition(i,new Vector3(Mathf.Cos(th)*rr,Mathf.Sin(th)*rr,0)); }
    lr.widthMultiplier=scale*0.14f; lr.material=Mats.Sprite(Color.white); lr.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off; lr.receiveShadows=false;
    var g=new Gradient(); g.SetKeys(new[]{ new GradientColorKey(new Color(0.15f,0.3f,0.8f),0f), new GradientColorKey(new Color(0.4f,0.6f,0.95f),0.6f), new GradientColorKey(new Color(1f,0.88f,0.35f),1f) }, new[]{ new GradientAlphaKey(0.9f,0f), new GradientAlphaKey(0.9f,1f) }); lr.colorGradient=g;
    var s=go.AddComponent<Spin>(); s.axis=Vector3.forward; s.speed=speed; return go; }

  void BuildSecret(){
    Secret=new GameObject("SecretArea"); Secret.transform.SetParent(Dyn,false); Secret.transform.position=GatePos;
    var glow=M(new Color(0.5f,0.85f,1f),0.4f,2.5f); var gold=M(new Color(1f,0.85f,0.3f),0.4f,2f); var t=Secret.transform;
    Prim(t,PrimitiveType.Cube,new Vector3(-2.2f,2f,0),new Vector3(0.6f,4f,0.6f),gold); Prim(t,PrimitiveType.Cube,new Vector3(2.2f,2f,0),new Vector3(0.6f,4f,0.6f),gold); Prim(t,PrimitiveType.Cube,new Vector3(0,4.2f,0),new Vector3(5f,0.6f,0.6f),gold,false);
    var q=GameObject.CreatePrimitive(PrimitiveType.Quad); Object.Destroy(q.GetComponent<Collider>()); q.transform.SetParent(t,false); q.transform.localPosition=new Vector3(0,2f,0); q.transform.localScale=new Vector3(3.8f,3.8f,1f);
    var qm=Mats.Sprite(new Color(0.6f,0.85f,1f,0.55f)); qm.mainTexture=Mats.Dot(); q.GetComponent<Renderer>().material=qm;
    for(int i=0;i<14;i++){ float an=i/14f*Mathf.PI*2f; Prim(t,PrimitiveType.Sphere,new Vector3(Mathf.Cos(an)*5f,0.25f,Mathf.Sin(an)*5f-3f),Vector3.one*0.35f,glow,false); }
    var l=new GameObject("GateLight").AddComponent<Light>(); l.transform.SetParent(t,false); l.transform.localPosition=new Vector3(0,2.5f,-1.5f); l.color=new Color(0.6f,0.85f,1f); l.range=18f; l.intensity=2.5f;
    var sw=MakeSwirl(t,new Vector3(0,9f,0),3.5f,40f); sw.transform.rotation=Quaternion.identity;
    Secret.SetActive(false); }
}
}
